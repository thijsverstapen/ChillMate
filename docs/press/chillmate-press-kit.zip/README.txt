ChillMate press kit
Version 4.2.1 (build 422)

One line
ChillMate is a calm, private place to look after yourself, with everything kept on your own iPhone.

One paragraph
ChillMate keeps your logs, reflections, plans, reminders and personal-safety tools in one private overview on your iPhone and Apple Watch. It has no account, no server and no trackers, so nothing about you is held anywhere you cannot reach. Alongside the private log it offers breathing and grounding tools, a combination checker, discreet check-in timers, a safe route home, and a country-aware directory of real crisis and health services that works offline. It is free, open source, and made by one developer in the Netherlands.

Site: https://thijsverstapen.github.io/ChillMate/
Source: https://github.com/thijsverstapen/ChillMate
Contact: chillmate@icloud.com

Please do not describe ChillMate as medical software, a diagnostic tool, or a crisis service.
